(* Wolfram Language Init File *)

Get[ "FeynCalc`FeynCalc`"]
